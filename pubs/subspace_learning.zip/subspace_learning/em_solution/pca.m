function pcam = pca(data, para)

[~, N] = size(data);

MN = mean(data, 2);   
pcam.MN = MN;

data = data - repmat(MN, [1,N]);
A = data;

[PC, S0] =  svd(A,0);
pcam.PC2 = PC(:, 1:para.K2);


