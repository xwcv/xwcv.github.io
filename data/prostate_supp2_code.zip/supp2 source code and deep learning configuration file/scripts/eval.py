import os
import sys
import time
import numpy as np
from PIL import Image
import cPickle
import logging
import math

import caffe


class ImagenetClassifier(object):
    default_args = {
        'model_def_file': ('./models/prostate/deploy.prototxt'),
        'pretrained_model_file': ('./models/prostate/net_iter_100.caffemodel'),
        'mean_file': ('./data/prostate/mean.binaryproto')
    }

    for key, val in default_args.iteritems():
        if not os.path.exists(val):
            raise Exception(
                "File for {} is missing. Should be at: {}".format(key, val))

    default_args['image_dim'] = 360
    default_args['raw_scale'] = 255.
    default_args['gpu_mode'] = True

    def __init__(self, model_def_file, pretrained_model_file, mean_file,
                 raw_scale, image_dim, gpu_mode):
        logging.info('Loading net and associated files...')

        blob = caffe.proto.caffe_pb2.BlobProto()
        data = open( mean_file , 'rb' ).read()
        blob.ParseFromString(data)

        mean = np.array( caffe.io.blobproto_to_array(blob) )[0]
        mean = mean[:, 36:-36, 36:-36]

        # mean = np.array( caffe.io.blobproto_to_array(blob) )[0].mean(1).mean(1)

        if gpu_mode:
            caffe.set_mode_gpu()
        else:
            caffe.set_mode_cpu()

        self.net = caffe.Classifier(
            model_def_file, pretrained_model_file,
            image_dims=(image_dim, image_dim), raw_scale=raw_scale,
            mean=mean, channel_swap=(2,1,0)
        )


    def classify_image(self, image):
        try:
            starttime = time.time()
            scores = self.net.predict([image], oversample=False).flatten()
            endtime = time.time()

            indices = (-scores).argsort()
            
            return (indices, scores, '%.3f' % (endtime - starttime))

        except Exception as err:
            logging.info('Classification error: %s', err)
            return (False, 'Something went wrong when classifying the '
                           'image. Maybe try another one?')


def eval(iter, round):
    ImagenetClassifier.default_args.update({'pretrained_model_file': ('./models/prostate/net_iter_'+str(iter)+'.caffemodel')})

    clf = ImagenetClassifier(**ImagenetClassifier.default_args)
    clf.net.forward()

    pre = './data/prostate/'
    prostate = cPickle.load( open('./data/prostate/prostate.dat', 'rb') )
    bags = prostate['bags']

    n_correct, n_total = 0, 0
    b_correct, b_total = 0, 0

    res = []
    for bag in bags:
        if bag[2] == 1:     # a training bag
            continue

        gt = bag[1]
        probs = np.empty((0,2))

        for inm, nm in enumerate( bag[0] ):

            image = caffe.io.load_image(pre+nm)

            [indices, scores, t] = clf.classify_image(image)

            probs = np.vstack((probs, scores))

            n_total += 1
            if indices[0] == gt:
                n_correct += 1

        b_total += 1 

        prob_vote = probs.mean(0)
        print prob_vote

        if np.argmax(prob_vote) == gt:
            b_correct += 1

        res.append( (bag, probs)  )    
        print 'time: ' + t + ', accuracy of instance: ' + ('%.3f' % (float(n_correct)/n_total)) + ', accuracy of bag: ' + ('%.3f' % (float(b_correct)/b_total))
   

    print 'correct, total:', n_correct, n_total
    print 'correct, total:', b_correct, b_total
   
    path_res = 'exp/prostate/res/'+'round_'+str(round)+'_iter_'+str(iter)+'.dat'
    with open(path_res, 'w') as f:
        cPickle.dump(res, f)
        print path_res


if __name__ == '__main__':

    iter = sys.argv[1]
    round = sys.argv[2]

    iter = str(iter)
    round = str(round)

    eval(iter, round)

    














