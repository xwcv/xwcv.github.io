import sys
import cPickle
import random

path_prostate = './data/prostate/prostate_db.dat'
prostate = cPickle.load( open(path_prostate, 'rb') )
bags = prostate['bags']

K = 10
step = float(len(bags))/K

random.shuffle(bags)

for k in range(K):
    istart = int( round(k*step) )
    iend = int( round((k+1)*step-1) )


    f_tr = open('data/prostate/10folds/list_train_'+str(k+1)+'.txt', 'w')
    f_val = open('data/prostate/10folds/list_val_'+str(k+1)+'.txt', 'w')

    for ibag, bag in enumerate(bags):

        nms = bag[0]
        gt = bag[1]

        if len(nms) < 5:
            import pdb; pdb.set_trace()

        if ibag<istart or ibag>iend:
            f_current = f_tr
            bags[ibag] = (nms, gt, 1)
        else:
            f_current = f_val
            bags[ibag] = (nms, gt, 0)

        for nm in nms:
            f_current.write( nm+' '+str(gt)+'\n' )

    # write back and save
    prostate['bags'] = bags

    with open( './data/prostate/10folds/prostate_'+str(k+1)+'.dat', 'w') as f:
        cPickle.dump(prostate, f)




