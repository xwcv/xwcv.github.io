import matplotlib.pyplot as plt
import numpy as np
import re


def smooth_trasparent(plt, iter, mean_array, std_array, color, smooth_alpha = 0.1):
    mean_array = np.array(mean_array)
    std_array = np.array(std_array)

    for current_alpha in np.arange(0,1,smooth_alpha):
        plt.fill_between(iter, mean_PlyCount - std_PlyCount*(1-current_alpha), mean_PlyCount - std_PlyCount*(1-current_alpha-smooth_alpha), color = a, alpha=current_alpha)
        plt.fill_between(iter, mean_PlyCount + std_PlyCount*(1-current_alpha-smooth_alpha), mean_PlyCount + std_PlyCount*(1-current_alpha), color = a, alpha=current_alpha)
    plt.fill_between(iter, mean_PlyCount - std_PlyCount*(1-current_alpha), mean_PlyCount + std_PlyCount*(1-current_alpha), color = a, alpha = 1)

def list_index(array,id_list):
    new_array = []
    for id in id_list:
        new_array.append(array[id])
    return new_array

#read data
iter = np.arange(0,1001,20)

with open('./exp/prostate/result_10_fold.txt', 'r') as f:
    for line in f:
        if line.startswith('mean'):
            mean_list = map(float, line.strip().split()[1::])
            #print mean_list
        if line.startswith('std'):
            std_list = map(float, line.strip().split()[1::])
            #print std_list


#plot data
#color_sequence = [(31, 119, 180), (174, 199, 232), (255, 127, 14), (255, 187, 120),
#             (44, 160, 44), (152, 223, 138), (214, 39, 40), (255, 152, 150),
#             (148, 103, 189), (197, 176, 213), (140, 86, 75), (196, 156, 148),
#            (227, 119, 194), (247, 182, 210), (127, 127, 127), (199, 199, 199),
#             (188, 189, 34), (219, 219, 141), (23, 190, 207), (158, 218, 229)]
color_sequence = [(23, 190, 200)]
# Scale the RGB values to the [0, 1] range, which is the format matplotlib accepts.
for i in range(len(color_sequence)):
    r, g, b = color_sequence[i]
    color_sequence[i] = (r / 255., g / 255., b / 255.)

for ia,a in enumerate(color_sequence):
    print ia,a
    fig, ax = plt.subplots(1)

    mean_PlyCount = np.array(mean_list)
    std_PlyCount = np.array(std_list)

    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

    # Ticks on the right and top of the plot are generally unnecessary chartjunk.
    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()

    plt.xlim( 0, 1010 )    # set the xlim to xmin, xmax
    plt.ylim( 0, 1)
    plt.xticks( np.arange(0, 1010, 100) )
    plt.yticks( np.arange(0, 1.01, 0.1),['0%','10%','20%','30%','40%','50%', '60%', '70%', '80%', '90%', '100%'] )

    for y in np.arange(0, 1, 0.1):
        plt.plot(np.arange(0,1000), [y] * len(np.arange(0,1000)), '--', lw=0.5, color='black', alpha=0.3)

    # top
    smooth_trasparent(plt, iter, mean_PlyCount, std_PlyCount, color=a, smooth_alpha = 0.01)

    plt.plot(iter, mean_PlyCount, color='white', lw=3)

    #plt.errorbar(range(0,1001,20), mean_list, std_list)
    #plt.errorbar(iter, mean_PlyCount, std_PlyCount, marker='o', ls='solid', lw=2, mec=a, capthick=2, capsize=5, color=a)
    plt.ylabel('Accuracy', fontname='Times New Roman')
    plt.xlabel('Iteration', fontname='Times New Roma')
    plt.show()
        #plt.savefig('./exp/prostate/figure.png', format='png', dpi=600)
