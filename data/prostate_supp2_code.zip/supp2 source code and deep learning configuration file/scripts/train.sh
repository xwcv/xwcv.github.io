

./build/tools/caffe train -solver models/prostate/solver.prototxt -gpu 1 -weights data/bvlc_reference_caffenet.caffemodel

