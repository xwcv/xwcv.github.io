function [x, score, pcams] = learn_rpca_model_em(f, x, ibag, para)

t = 0;
len = size(f,2);
pcams = {};

alld = inf;
while 1
    t = t+1;
    % fprintf('iteration %d.\n', t);
    fprintf('*');
    
    % learn a (r)pca model
    if para.rpca
        pcam = pca_r(f(:,x==1), para);
    else
        pcam = pca(f(:,x==1), para);
    end

    % reconstruction
    d_ = zeros(1, len );
    parfor i = 1:len
        d_(i) = reconstruct(pcam, f(:,i), para);
    end

    x2 = zeros(1, len );
    for i = 1:length(ibag)
        helpi = ibag{i};
        
        [~, mi] = sort(d_(helpi), 'ascend');
        x2( helpi(mi(1:min(para.npos,length(mi)))) ) = 1;
    end

    % if sum(abs(x-x2))==0 || t>=para.max_iter
    if x2*d_'>=alld || t>=para.max_iter
        fprintf('\n');
        break;
    else
        alld = x2*d_';
        x = x2;
        score = exp(-d_/mean(d_));
        pcams{end+1} = pcam;
    end
end

