
# %% 1
# Package imports
import matplotlib.pyplot as plt
import numpy as np
import sklearn
import sklearn.datasets
import sklearn.linear_model
import matplotlib
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from pprint import pprint

import sys
sys.path.append('mnist')
import mnist

train_images = mnist.train_images()
train_labels = mnist.train_labels()

test_images = mnist.test_images()
test_labels = mnist.test_labels()

n_train, w, h = train_images.shape
X_train = train_images.reshape( (n_train, w*h) )
Y_train = train_labels

n_test, w, h = test_images.shape
X_test = test_images.reshape( (n_test, w*h) )
Y_test = test_labels

print(X_train.shape, Y_train.shape)
print(X_test.shape, Y_test.shape)

X_train = (X_train.astype(float) - 128.0) / 128.0
X_test  = (X_test.astype(float) - 128.0) / 128.0

# %% 7
# Helper function to evaluate the total loss on the dataset
def calculate_loss(model, X, y):
    W1, b1, W2, b2, W3, b3 = model['W1'], model['b1'], model['W2'], model['b2'], model['W3'], model['b3']
    # Forward propagation to calculate our predictions
    z1 = X.dot(W1) + b1
    a1 = np.tanh(z1)
    z2 = a1.dot(W2) + b2
    a2 = np.tanh(z2)
    z3 = a2.dot(W3) + b3
    exp_scores = np.exp(z3)
    probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
    # Calculating the loss
    num_examples = X.shape[0]
    corect_logprobs = -np.log(probs[range(num_examples), y])
    data_loss = np.sum(corect_logprobs)
    # Add regulatization term to loss (optional)
    data_loss += reg_lambda/2 * (np.sum(np.square(W1)) + np.sum(np.square(W2)))
    return 1./num_examples * data_loss

# %% 8
# Helper function to predict an output (0 or 1)
def predict(model, x):
    W1, b1, W2, b2, W3, b3 = model['W1'], model['b1'], model['W2'], model['b2'], model['W3'], model['b3']
    # Forward propagation
    z1 = x.dot(W1) + b1
    a1 = np.tanh(z1)
    z2 = a1.dot(W2) + b2
    a2 = np.tanh(z2)
    z3 = a2.dot(W3) + b3
    exp_scores = np.exp(z3)
    probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
    return np.argmax(probs, axis=1)

# %% 16
# This function learns parameters for the neural network and returns the model.
# - nn_hdim: Number of nodes in the hidden layer
# - num_passes: Number of passes through the training data for gradient descent
# - print_loss: If True, print the loss every 1000 iterations
def build_model(X, y, nn_hdim, epsilon, reg_lambda, num_passes=20000,  print_loss=False):

    # Initialize the parameters to random values. We need to learn these.
    np.random.seed(0)
    num_examples = X.shape[0]
    nn_input_dim = nn_hdim[0]
    print('input dim:', nn_input_dim)

    hdim1 = nn_hdim[1]
    W1 = np.random.randn(nn_input_dim, hdim1) / np.sqrt(hdim1)
    b1 = np.zeros((1, hdim1))
    print('fc: %d -> %d'%(nn_input_dim, hdim1))

    hdim2 = nn_hdim[2]
    W2 = np.random.randn(hdim1, hdim2) / np.sqrt(hdim2)
    b2 = np.zeros((1, hdim2))
    print('fc: %d -> %d'%(hdim1, hdim2))

    hdim3 = nn_hdim[3]
    W3 = np.random.randn(hdim2, hdim3) / np.sqrt(hdim3)
    b3 = np.zeros((1, hdim3))
    print('fc: %d -> %d'%(hdim2, hdim3))

    # This is what we return at the end
    model = {}
    bs = 128
    nbs_per_epoch = int(num_examples/bs)

    # Gradient descent. For each batch...
    for i in range(0, num_passes):

        j = i % nbs_per_epoch
        if 0 == j:
            ridx = np.asarray( list (range(num_examples))   )
            np.random.shuffle( ridx )
            X = X[ridx, :]
            y = y[ridx]

        Xb = X[j*bs:(j+1)*bs, :]
        yb = y[j*bs:(j+1)*bs]

        # Forward propagation
        z1 = Xb.dot(W1) + b1
        a1 = np.tanh(z1)
        z2 = a1.dot(W2) + b2
        a2 = np.tanh(z2)
        z3 = a2.dot(W3) + b3
        exp_scores = np.exp(z3)
        probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)

        # Backpropagation
        delta_loss = probs
        delta_loss[range(bs), yb] -= 1

        dW3 = (a2.T).dot(delta_loss)
        db3 = np.sum(delta_loss, axis=0, keepdims=True)

        delta3 = delta_loss.dot(W3.T) * (1 - np.power(a2, 2))
        dW2 = (a1.T).dot(delta3)
        db2 = np.sum(delta3, axis=0, keepdims=True)

        delta2 = delta3.dot(W2.T) * (1 - np.power(a1, 2))
        dW1 = (Xb.T).dot(delta2)
        db1 = np.sum(delta2, axis=0)

        # Add regularization terms (b1 and b2 don't have regularization terms)
        dW3 += reg_lambda * W3
        dW2 += reg_lambda * W2
        dW1 += reg_lambda * W1

        # Gradient descent parameter update
        W1 += -epsilon * dW1
        b1 += -epsilon * db1
        W2 += -epsilon * dW2
        b2 += -epsilon * db2
        W3 += -epsilon * dW3
        b3 += -epsilon * db3

        # Assign new parameters to the model
        model = { 'W1': W1, 'b1': b1, 'W2': W2, 'b2': b2, 'W3': W3, 'b3': b3}

        # Optionally print the loss.
        # This is expensive because it uses the whole dataset, so we don't want to do it too often.
        if print_loss and i % 1000 == 0:
          epsilon *= 0.99
          y_pred = predict(model, X_test)
          accuracy = sum(0==(y_pred-Y_test))/Y_test.shape[0]
          print("Loss after iteration {}: {:.2f}, testing accuracy: {:.2f}%".format(i, calculate_loss(model, X, y), accuracy*100))

    return model

# %% 17
# Build a model with a 3-dimensional hidden layer

num_examples, input_dim = X_train.shape
epsilon = 0.001
reg_lambda = 0.00


model = build_model(X_train, Y_train, [input_dim,256,512,10], epsilon, reg_lambda, 50000, print_loss=True)

# Plot the decision boundary
# plot_decision_boundary(lambda x: predict(model, x))
# plt.title("Decision Boundary for hidden layer size 3")
# plt.show()




