"""
No test framework is used at the moment. Tests can be executed
from the root directory with:

# python -m unittest discover tests
"""
