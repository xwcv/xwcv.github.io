function d = reconstruct(pcam, y, para)

    if para.rpca
        y1 = y - pcam.MN;
        [~, e1] = min_l1( pcam.PC1, y1, 1 );
        % d = sum(abs(e1))/length(e1);
        d = sqrt(sum(e1.^2))/ length(e1);
    else
        y = y - pcam.MN;
        e2 = y - pcam.PC2*(pcam.PC2'*y);
        d = sqrt(sum(e2.^2)/length(e2));
    end
    