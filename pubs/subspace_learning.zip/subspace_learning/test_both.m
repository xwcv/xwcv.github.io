


clear; clc;
addpath em_solution\
addpath em_solution\PROPACK\


% parameters 
rho  = 1.01;
nbag = 50;

para.rpca = 1;
para.npos = 1;
para.max_iter = 100;     % maximal interations


error_ratio = 0.05;
nrank = 5;
    

[X, I, Z, Z_gt] = generate_synthetic_data( error_ratio, nrank, nbag );
para.lambda = 1/sqrt(size(X,1));

tic
[Z_get_alm, A_get, E_get] = alm(X, Z, I, para.lambda, rho);
toc
a_alm = eval_indicators(Z_get_alm, Z_gt);
            
tic
[Z_get_em, score, pcams] = learn_rpca_model_em( X, Z, I, para );
toc
a_em = eval_indicators(Z_get_em, Z_gt);


fprintf('ADMM: accuracy of the predict of indicators is %f.\n', a_alm);
fprintf('NIM: accuracy of the predict of indicators is %f.\n', a_em);
 

