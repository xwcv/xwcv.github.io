#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright © 2016 yyl     Huazhong University of Science and Technology
#
# Distributed under terms of the MIT license.
from datetime import datetime
import os, time, sys
os.environ['CUDA_VISIBLE_DEVICES'] = ''

import argparse
import cPickle as pickle
import numpy as np
from sklearn import metrics

import tensorflow as tf
import tensorflow.contrib.slim as slim
from lib.capsule import capsule
from lib.data_loader import DataLoader

def parse_args():
    parser = argparse.ArgumentParser(description='Train MIL Network')
    parser.add_argument('--dataset', dest='dataset', help='', default='musk1', type=str)
    parser.add_argument('--lr', dest='init_lr', help='', default=5e-4, type=float)
    parser.add_argument('--decay', dest='weight_decay', help='', default=5e-3, type=float)
    parser.add_argument('--dim', dest='dimension', help='', default=166, type=int)
    parser.add_argument('--max_epoch', dest='max_epoch', help='', default=10000, type=int)
    parser.add_argument('--decay_step', dest='decay_step', help='', default=250, type=int)
    parser.add_argument('--id', dest='id', help='', default=0, type=int)

    args = parser.parse_args()
    return args

class mi_net(object):
    def __init__(self, dataset, args):
        self.start_lr = args.init_lr
        self.train_iters = args.max_epoch
        self.datasets = dataset
        self.dimension = args.dimension
        self.display_step = 20
        self.snapshot = 20
        self.model_save_dir = './model'
        self.batch_size = 1
        self.weight_decay = args.weight_decay
        self.stddev = 0.05

    def model(self, inputs, is_training):
        with slim.arg_scope([slim.fully_connected],
                            activation_fn=tf.nn.relu,
                            weights_initializer=tf.truncated_normal_initializer(stddev=self.stddev),
                            weights_regularizer=slim.l2_regularizer(self.weight_decay),
                            ):
            
            net = slim.fully_connected(inputs, 256, scope='fc1')
            net = slim.fully_connected(net, 128, scope='fc2')
            net = slim.fully_connected(net, 64, scope='fc3', activation_fn=None)
            
            net, logits = capsule(net, 10, 3, 'capsule', 64, 64, 3)

            return tf.norm(net), logits

    def margin_loss(self, labels, raw_logits, is_training, margin=0.4, downweight=1.0):
        logits = raw_logits - 0.5
        positive_cost = labels * tf.cast(tf.less(logits, margin),
                tf.float32) *tf.pow(logits -margin, 2)
        negative_cost = (1 - labels) * tf.cast(tf.greater(logits, -margin), tf.float32)*tf.pow(logits+margin, 2)
        cost = (positive_cost + negative_cost) * 10
        tf.add_to_collection('losses', cost)

        regularization_losses = tf.add_n(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
        tf.add_to_collection('losses', regularization_losses)
        return tf.cond(is_training,
                        lambda: tf.add_n(tf.get_collection('losses'), name='total_loss'),
                        lambda: cost)

    def compute_accuracy(self, y, logits):
        return tf.equal(y, tf.round(logits))


    def run_net1(self, neurons, mode='MI-Net', fold=0):
        fea = tf.placeholder(tf.float32, shape=(None, self.dimension), name='fea')
        label = tf.placeholder(tf.float32, name='label')
        is_training = tf.placeholder(tf.bool, name='is_training')

        if mode == 'MI-Net':
            preds, f = self.model(fea, is_training)
        cost = self.margin_loss(label, preds, is_training)
        accuracy = self.compute_accuracy(label, preds)
        global_step = tf.Variable(0, trainable=False)
        learning_rate = tf.train.exponential_decay(self.start_lr, global_step, args.decay_step, 0.96, staircase=True)
        optimizer = tf.train.AdamOptimizer(learning_rate).minimize(cost, global_step)

        init = tf.initialize_all_variables()
        saver = tf.train.Saver(max_to_keep=50)

        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.3)

        with tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)) as sess:
            sess.run(init)
            best_te_loss = 100.
            step = 0
            temp_loss = 0
            while step < self.train_iters:
                
                batch_fea, batch_label = self.datasets.get_next_batch(step, fold, is_train=True)
                start_time = time.time()
                # load batch_data
                _, batch_loss, res1, res2= sess.run([optimizer, cost, preds, f],
                                              feed_dict={fea: batch_fea, label: batch_label,
                                                         is_training: True})
                duration = time.time() - start_time
                temp_loss += batch_loss
                if step % self.display_step == 0:
                    examples_per_sec = self.batch_size / duration
                    sec_per_batch = float(duration)

                    format_str = ('%s: step = %d, loss = %.5f ( %.1f example/sec; %.3f sec/batch)')
                    print format_str % (datetime.now(), step, temp_loss/self.display_step, examples_per_sec, sec_per_batch)
                    temp_loss = 0
                if step % self.snapshot == 0 or (step + 1) == self.train_iters:

                    # eval on test set
                    num_te_batch = len(self.datasets.datasets.data[fold]['test'])
                    te_loss = np.zeros((num_te_batch,), dtype=np.float32)
                    y_pred = np.zeros((num_te_batch,), dtype=np.float32)
                    y_true = np.zeros((num_te_batch,), dtype=np.int)
                    te_acc = np.zeros((num_te_batch,), dtype=np.float32)
                    for idx in range(num_te_batch):
                        te_batch_fea, te_batch_label = self.datasets.get_next_batch(idx, fold, is_train=False)
                        te_loss[idx], y_pred[idx], te_acc[idx] = sess.run([cost, preds, accuracy],
                                                                          feed_dict={fea: te_batch_fea,
                                                                                     label: te_batch_label,
                                                                                     is_training: False})
                        y_true[idx] = te_batch_label
                    te_loss = np.mean(te_loss)
                    te_acc = np.mean(te_acc)
                    fpr, tpr, thresholds = metrics.roc_curve(y_true, y_pred, pos_label=1)
                    auc_val = metrics.auc(fpr, tpr)
                    format_str = ('%s: step = %d, test loss = %.4f, auc = %.4f, acc = %.4f')
                    print 'Evaluate on test set:'
                    print format_str % (datetime.now(), step, te_loss, auc_val, te_acc)

                step = step + 1
            print 'Optimization Finished!'

            # compute test accuracy of best model
            saver.restore(sess, self.model_save_dir + '/best_model2.ckpt')
            num_te_batch = len(self.datasets.datasets.data[fold]['test'])

            te_loss = np.zeros((num_te_batch,), dtype=np.float32)
            y_pred = np.zeros((num_te_batch,), dtype=np.float32)
            y_true = np.zeros((num_te_batch,), dtype=np.int)
            te_acc = np.zeros((num_te_batch,), dtype=np.float32)
            for idx in range(num_te_batch):
                te_batch_fea, te_batch_label = self.datasets.get_next_batch(idx, fold, is_train=False)
                te_loss[idx], y_pred[idx], te_acc[idx] = sess.run([cost, preds, accuracy],
                                                                  feed_dict={fea: te_batch_fea, label: te_batch_label,
                                                                             is_training: False})
                y_true[idx] = te_batch_label
            te_loss = np.mean(te_loss)
            te_acc = np.mean(te_acc)
            fpr, tpr, thresholds = metrics.roc_curve(y_true, y_pred, pos_label=1)
            auc_val = metrics.auc(fpr, tpr)
            format_str = ('%s: step = %d, test loss = %.4f, auc = %.4f, acc = %.4f')
            print 'Evaluate on test set:'
            print format_str % (datetime.now(), step, te_loss, auc_val, te_acc)
            
            saver.save(sess, self.model_save_dir + '/best_model2.ckpt')
            sess.close()
        return te_acc, auc_val

    def eval(self, neurons, mode='MI-Net', fold=0):
        fea = tf.placeholder(tf.float32, shape=(None, self.dimension), name='fea')
        label = tf.placeholder(tf.float32, name='label')
        is_training = tf.placeholder(tf.bool, name='is_training')

        if mode == 'MI-Net':
            preds, f = self.model(fea, is_training)
        
        init = tf.initialize_all_variables()
        saver = tf.train.Saver(max_to_keep=50)
        
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.3)

        with tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)) as sess:
            sess.run(init)
            saver.restore(sess, self.model_save_dir + '/best_model2.ckpt')
            num_te_batch = len(self.datasets.datasets.data[fold]['test'])
            for idx in range(num_te_batch):
                te_batch_fea, te_batch_label = self.datasets.get_next_batch(idx, fold, is_train=False)
                res = sess.run([f], feed_dict={fea:te_batch_fea, label:te_batch_label, is_training:False})       
                print(res)


if __name__ == '__main__':
    mode = 'MI-Net'

    args = parse_args()
    dataset_nm = args.dataset
    seed = [23+i*5 for i in range(10)]
    layers_mode = [[256, 128, 64]]
    te_acc = np.zeros((5, 10))
    te_auc = np.zeros((5, 10))
    for idx in range(5):
        dataset = DataLoader(dataset_nm, seed[idx], args.id)
        for fold in range(10):
            print 'run=', idx, ' fold=', fold
            net = mi_net(dataset, args)
            te_acc[idx][fold], te_auc[idx][fold] = net.run_net1(layers_mode[0], mode, fold)
            net.eval(layers_mode[0], mode, fold)
            tf.reset_default_graph()
    print dataset_nm
    print te_acc
    print te_auc
    print 'MI-Net:'
    print 'accuracy = ', np.mean(te_acc)
    print 'std = ', np.std(te_acc)
    print 'AUC = ', np.mean(te_auc)
    print 'std = ', np.std(te_auc)

    with file('./result.txt', 'a+') as f:
        f.write(net.datasets.dataset_nm+'\n')
        f.write('acc:')
        f.write('mean=' + str(np.mean(te_acc)) + ' std=' + str(np.std(te_acc)) + '\n')
        f.write('auc:')
        f.write('mean=' + str(np.mean(te_auc)) + ' std=' + str(np.std(te_auc)) + '\n')
        f.close()
