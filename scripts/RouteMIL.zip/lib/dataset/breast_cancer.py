from __future__ import absolute_import
import os
import numpy as np
import scipy.io as sio
from sklearn.model_selection import KFold

class BreastCancer(object):
    def __init__(self, seed, id):
        self.data_dir = './dataset'
        self.seed = seed
        self.dataset_name = 'ucsb_breast'
        self.id = id
        self.data = self.load_dataset()

    def load_dataset(self):
        data = sio.loadmat(os.path.join(self.data_dir, 'ucsb_breast.mat'))
        ins_fea = data['x']['data'][0,0]
        bags_nm = data['x']['ident'][0,0]['milbag'][0,0][:,0]
        bags_label = data['x']['nlab'][0,0][:, 0] - 1

        self.num_classes = bags_label.shape[0]
        self.num_bags = bags_nm[-1]
        
        #mean_fea = np.mean(ins_fea, axis=0, keepdims=True)
        #std_fea = np.mean(ins_fea, axis=0, keepdims=True) + 1e-6
        #ins_fea = np.divide(ins_fea - mean_fea, std_fea)

        max_fea = np.max(ins_fea, axis=0, keepdims=True)
        min_fea = np.min(ins_fea, axis=0, keepdims=True)
        ins_fea = np.divide(ins_fea-min_fea, max_fea-min_fea+1e-6) 

        # store data in bag form
        bags = {}
        for idx, bag_nm in enumerate(bags_nm):
            if bags.has_key(bag_nm):
                bags[bag_nm]['fea'].append(ins_fea[idx])
            else:
                bags[bag_nm] = {'fea': [ins_fea[idx]], 'label': bags_label[idx]}
        bags = bags.values()

        # random select 90% bags as train, others as test
        kf = KFold(n_splits=10, shuffle=True, random_state=self.seed)
        datasets = []
        for train_idx, test_idx in kf.split(bags):
            tr_bags = []
            te_bags = []
            for ibag in train_idx:
                tr_bags.append(bags[ibag])
            for ibag in test_idx:
                te_bags.append(bags[ibag])
            datasets.append({'train': tr_bags, 'test': te_bags})
        return datasets
