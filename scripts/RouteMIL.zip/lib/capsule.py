"""
Library for capsule layers.

This has the layer implementation for layers.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf

def _squash(input_tensor):
    """
    Applies norm nonlinearity (squash) to a capsule layer.
    :param input_tensor: Input tensor. Shape is [num_instances, num_atoms] for a fully connected capsule layer.
    :return:
        A tensor with same shape as input (rank 2) for output of this layer.
    """
    with tf.name_scope('norm_non_linearity'):
        norm = tf.norm(input_tensor, axis=1, keep_dims=True) + 1e-5
        norm_squared = norm * norm
        return (input_tensor / norm) * (norm_squared / (1 + norm_squared))

def _update_routing(votes, logit_shape, num_dims, input_dim, output_dim, num_routing):
    """
    Sums over scaled votes and applies squash to compute the activations.

    Iteratively updates routing logits (scales) based on the similarity between
    the activation of this layer and votes of the layer below.

    :param votes: tensor, The transformed outputs of the layer below.
    :param logit_shape: tensor, shape of the logit to be initialized.
    :param num_dims: scalar, number of dimmensions in votes. For fully connected capsule it is 4.
    :param input_dim: scalar, number of capsules in the input layer.
    :param output_dim: scalar, number of capsules in the output layer.
    :param num_routing: scalar, number of routing iterations.
    :return:
        The activation tensor of the output layer after num_routing iterations.
    """
    votes_t_shape = [2, 0, 1]
    r_t_shape = [1, 2, 0]
    votes_trans = tf.transpose(votes, votes_t_shape)
    
    def _body(i, logits, activations):
        """Routing while loop."""
        route = tf.nn.softmax(logits, dim=0)
        preactivate_unrooled = route * votes_trans
        preact_trans = tf.transpose(preactivate_unrooled, r_t_shape)
        preactivate = tf.reduce_sum(preact_trans, axis=0)
        activation =_squash(preactivate)
        activations = activations.write(i, activation)
        # distances: [batch, input_dim, output_dim]
        distances = tf.reduce_sum(votes * activation, axis=2)
        logits += distances
         
        def f1():   return logits
        def f2():   return route
        return (i + 1, tf.case([(tf.less(i+1, num_routing), f1)], default=f2), activations)

    activations = tf.TensorArray(
        dtype=tf.float32, size=num_routing, clear_after_read=False)
    logits = tf.fill(logit_shape, 0.0)
    i = tf.constant(0, dtype=tf.int32)
    _, logits,activations = tf.while_loop(
        lambda i, logits, activations: i < num_routing,
        _body,
        loop_vars=[i, logits, activations],
        swap_memory=True)
    return activations.read(num_routing - 1), logits

def capsule(input_tensor, input_dim, output_dim, layer_name, input_atoms=64, output_atoms=64, num_routing=3):
    """
    Build a fully connected capsule layer.

    Given an input tensor of shape `[batch, input_dim, input_atom]`, this op performs the following:
        1. scales the votes for each output capsule by iterative routing.
        2. squashes the output of each capsule to have norm less than one.

    :param input_tensor: tensor, activation output of the layer below.
    :param input_dim: scalar, number of capsules in the layer below.
    :param output_dim: scalar, number of capsules in this layer.
    :param layer_name: string, Name of this layer.
    :param input_atoms: scalar, number of units in each capsule of input layer.
    :param output_atoms: scalar, number of units in each capsule of output layer.
    :param routing_args: dicitionary {num_routing},args for routing function.
    :return:
        Tensor of activations for this layer of shape
        `[batch, output_dim, output_atoms]`.
    """
    with tf.variable_scope(layer_name):
        votes_reshaped = tf.expand_dims(input_tensor, axis=1)
        
        with tf.name_scope('routing'):
            input_shape = tf.shape(input_tensor)
            logit_shape = tf.stack([input_shape[0], output_dim])
            activations, logits = _update_routing(
                votes=votes_reshaped,
                logit_shape=logit_shape,
                num_dims=4,
                input_dim=input_dim,
                output_dim=output_dim,
                num_routing=num_routing)
            return activations, logits
