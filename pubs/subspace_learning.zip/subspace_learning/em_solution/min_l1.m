function [x, e]=min_l1(A, y, b_orthogonal)
% [x, e]=min_l1(A, y) tries to solve the least l1-norm fitting by
% minimizing the following objective function:
% min_{x} ||y-Ax||_1.
% The technique involved is purel brute-force alternating direction method
% on the transformed optimization problem with dummy variable e.
% min_{x, e} ||e||_1, s.t. y=Ax+e
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!important!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% Here to speed up the code, I've preprocessed A such that each column
% of A is normalized to unit length, and columns are orthogonal to each
% other. But to prevent wasting time on the redundant preprocessing over
% the same A for different y, you'd better directly pass me an orthogonal
% A, and set b_orthogonal to 1!
% ----------------------------input----------------------------------------
% A:        m*n matrix. In the code it is assumed that m>n
% y:        m*1 column vector. Instance vector.
% b_orthogonal:     1 means that columns of A are of unit length and
%                   orthogonal to each other.
% ---------------------------output----------------------------------------
% x:        n*1 vector. Reconstruction coefficients.
% e:        m*1 vector. Reconstruction error.

if nargin<3
    b_orthogonal=0;
end
norm_y=norm(y);
y=y/norm_y;

[m, n]=size(A);

if ~b_orthogonal
    [Q, R]=qr(A, 0);
else
    Q=A;
    R=eye(n);
end
Q_trans=Q';

iter=0;
stop_criterion=0;
max_iter=50;
mu=1/sqrt(m);
rho=2;
display_period=inf;

x=zeros(n, 1);
e=y;
Y=zeros(m, 1);
threshold=1e-6;
while 1
    iter=iter+1;
    x=Q_trans*(y-e+Y/mu);
    Qx=Q*x;
    temp1=y-Qx+Y/mu;
    e=sign(temp1).*(abs(temp1)>1/mu).*(abs(temp1)-1/mu);
    derivative=y-Qx-e;
    stop_criterion=sum(abs(derivative));
    if mod(iter, display_period)==0
        disp(['Iter ', num2str(iter), ': ||e||_1=', num2str(sum(abs(e))), ', stop_criterion=', num2str(stop_criterion)]);
    end
    if stop_criterion<threshold || iter>=max_iter
        break;
    end
    Y=Y+mu*derivative;
    mu=mu*rho;
end
x=R\x;

x=x*norm_y;
e=e*norm_y;