Code for robust subspace learning via relaxed rank minimization in the following paper:

Xinggang Wang, Zhengdong Zhang, Yi Ma, Xiang Bai, Wenyu Liu, and Zhuowen Tu, Robust Subspace Discovery via Relaxed Rank Minimization, Neural Computation 2013 (in press). 

The implementation of both the relaxed convex optimization method and the naive iterative method are included in this package. Please run "test_both.m" to test the both algorithms.

For any question, please contact Xinggang Wang (xgwang@hust.edu.cn).
