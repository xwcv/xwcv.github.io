
function [Z, A_hat, E_hat] = alm(X, Z, I, lambda, rho, maxIter)
% Multiple Instance Learning via Low-Rank optimization
% X: each column of X is an instance
% Z: indicator of instance
% I: a 1*N cell, in each cell, it contains the indices of instances in X
% and Z

[m n] = size(X);

if ~exist( 'lambda', 'var' );
    lambda = 1 / sqrt(m);
end
if ~exist( 'rho', 'var' )
    rho = 1.01;  
end
if ~exist('maxIter', 'var')
    maxIter = 1000;
end

tol = 1e-3;


% mu = 1.5/norm_two; % this one can be tuned
mu = 1e-1;
mu_bar = 1e30;
iter = 0;
total_svd = 0;
converged = false;

% [A_hat, E_hat, mu] = inexact_alm_rpca(D, lambda, rho);
% Y0(:) = 0;
% objv = zeros( 1, maxIter );

% initialize variables
A_hat = zeros( m, n);
E_hat = zeros( m, n);
Y0    = zeros( m, n);
Yk = zeros(1, length(I) );

pinva = cell( 1, length(I) );
for i = 1:length(I)
    I_ = I{i};
    X_  = X(:, I_);
    pinva{i} = pinv( diag(sum(X_.*X_)) + ones(length(I_)) );
end

D = ( X .* repmat(Z, size(X,1), 1) );

while ~converged       
    iter = iter + 1;
    
    % update E
    temp_T = D - A_hat + (1/mu)*Y0;
    E_hat = max(temp_T - lambda/mu, 0);
    E_hat = E_hat+min(temp_T + lambda/mu, 0);
            
    % svd
    [U S V] = svd(D - E_hat + (1/mu)*Y0, 'econ');

    % update sv (number of sigular value)
    diagS = diag(S);
    svp = length(find(diagS > 1/mu));
    
    % update A
    A_hat = U(:, 1:svp) * diag(diagS(1:svp) - 1/mu) * V(:, 1:svp)';    

    % update Z
    for i = 1:length(I)
        I_ = I{i};
        X_ = X(:, I_);
        P_ = A_hat(:, I_) + E_hat(:, I_) - (1/mu)*Y0(:, I_);
        Q_ = 1 - (1/mu)*Yk(i);
        Z(I_) = pinva{i} * (sum(X_.*P_)+Q_)';
    end
    
    % update D
    D = X .* repmat(Z, m, 1);
    
    total_svd = total_svd + 1;
    
    % update Y
    H0 = D - A_hat - E_hat;
    Y0 = Y0 + mu*H0;
    
    Hk = zeros( 1,length(I) );
    for i = 1:length(I)
        Hk(i) = sum( Z(I{i}) ) - 1;
        Yk(i) = Yk(i) + mu*Hk(i);
    end
    
    % update mu
    mu = min(mu*rho, mu_bar);
        
    % stop Criterion    
    % stopCriterion = norm(H0, 'fro') / d_norm;
    stopCriterion1 = norm(H0, 'fro');
    stopCriterion2 = norm(Hk, 'fro');
    if stopCriterion1 < tol && stopCriterion2 < tol
        converged = true;
    end    
    
    % get objective value
    % objv(iter) = get_objv(A_hat, D-A_hat, lambda);
    
    if mod( total_svd, 5) == 0
        if size(A_hat,1)*size(A_hat) > 1e6
            disp(['#svd ' num2str(total_svd) ' |A|_* = ', num2str(sum(diagS(:)))...
            ' |E|_0 ' num2str(length(find(abs(E_hat)>eps)))...
            ' stopCriterion: ' num2str(stopCriterion1) ' and ' num2str(stopCriterion2)]);
        else
            disp(['#svd ' num2str(total_svd) ' r(A) = ', num2str(rank(A_hat))...
                ' |E|_0 ' num2str(length(find(abs(E_hat)>eps)))...
                ' stopCriterion: ' num2str(stopCriterion1) ' and ' num2str(stopCriterion2)]);
        end
    end    
    
    if ~converged && iter >= maxIter
        disp('Maximum iterations reached') ;
        converged = 1 ;       
    end
end

% figure, plot( [1:iter], objv(1:iter) );
% xlabel('Iterations');
% ylabel('Objective value');





