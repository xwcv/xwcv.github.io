import sys
import cPickle
import numpy as np
from scipy.stats import norm
import csv

iter = 500
pre = './exp/prostate/res/'

result = []

l_b_tr = []
l_p_tr = []
l_b_te = []
l_p_te = []
l_b2b = []
l_b2p = []
l_p2b = []
l_p2p = []

for round in range(1,11,1):
    result_current = []

    prostate = cPickle.load( open( pre+'round_'+str(round)+'_iter_'+str(iter)+'.dat', 'rb'))

    b_tr, p_tr, b_te, p_te = np.array([0,0]), np.array([0,0]), np.array([0,0]), np.array([0,0])
    b2b, b2p, p2b, p2p = np.array([0,0]), np.array([0,0]), np.array([0,0]), np.array([0,0])

    for res in prostate:
        bag = res[0]
        probs = res[1]
        gt = bag[1]

        if bag[2] == 1:
            continue
        else:
            if gt == 0:
                b_te += np.array([1, len(probs)])
            else:
                p_te += np.array([1, len(probs)])

            prob_vote = probs.mean(0)
            predict =  np.argmax(prob_vote)

            if gt == 0 and predict == 0:
                b2b +=  np.array([1, len(probs)])

            if gt == 0 and predict == 1:
                b2p +=  np.array([1, len(probs)])

            if gt == 1 and predict == 0:
                p2b +=  np.array([1, len(probs)])

            if gt == 1 and predict == 1:
                p2p +=  np.array([1, len(probs)])


    prostate_src = cPickle.load( open('data/prostate/10folds/prostate_'+str(round)+'.dat', 'rb') )
    bags = prostate_src['bags']
    for bag in bags:
        gt = bag[1]

        if bag[2] == 1:
            if gt == 0:
                b_tr += np.array([1, len(bag[0])])
            else:
                p_tr += np.array([1, len(bag[0])])


    l_b_tr.append(b_tr)
    l_p_tr.append(p_tr)
    l_b_te.append(b_te)
    l_p_te.append(p_te)


    l_b2b.append(b2b)
    l_b2p.append(b2p)
    l_p2b.append(p2b)
    l_p2p.append(p2p)

# stat
l_tr = []
l_te = []
l_acc = []

for i in range(len(l_b_tr)):
    l_tr.append( l_b_tr[i] + l_p_tr[i]  )
    l_te.append( l_b_te[i] + l_p_te[i] )

    l_acc.append(  (l_b2b[i]+l_p2p[i]) / float(l_te[i][0]) )

# tab2 = np.vstack( ( l_tr, l_b_tr, l_p_tr, l_te, l_b_te, l_p_te, l_b2b, l_p2p, l_b2p, l_p2b, l_acc ) )
# print tab2

def format1(l):
    s = [str(v[0])+'('+str(v[1])+')' for v in l]
    return ','.join(s) + '\n'

def format2(l):
    s = [str(v) for v in l]
    return ','.join(s) + '\n'

with open('exp/prostate/tab2.csv', 'w') as fp:
    fp.write( format1(l_tr) )
    fp.write( format1(l_b_tr) )
    fp.write( format1(l_p_tr) )
    fp.write( format1(l_te) )
    fp.write( format1(l_b_te) )
    fp.write( format1(l_p_te) )
    fp.write( format1(l_b2b) )
    fp.write( format1(l_p2p) )
    fp.write( format1(l_b2p) )
    fp.write( format1(l_p2b) )
    fp.write( format2(l_acc) )































