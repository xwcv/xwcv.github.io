function pcam = pca_r(data, para)

[~, N] = size(data);

MN = mean(data, 2);   
pcam.MN = MN;

data = data - repmat(MN, [1,N]);

% robust pca
[A, E] = inexact_alm_rpca( double(data), para.lambda );



% % for debug
% [A, E] = inexact_alm_rpca( double(data), para.lambda );
% figure,
% subplot(1,3,1), imshow(double(data), []);
% subplot(1,3,2), imshow(A, []);
% subplot(1,3,3), imshow(E, []);

[PC, S0] =  svd(A);
S = diag(S0);
S = cumsum(S) / sum(S);

K1 = find(S>=0.999);
K1 = K1(1);
pcam.PC1 = PC(:, 1:K1);


% figure, imshow( HOGpicture(reshape(PC(:,1),[11,11,31])),[] )

