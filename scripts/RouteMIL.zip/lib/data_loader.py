import numpy as np
from random import shuffle
from dataset.birds import Birds
from dataset.breast_cancer import BreastCancer
from dataset.messidor import Messidor

class DataLoader(object):
    def __init__(self, dataset_nm, seed, id):
        self.dataset_nm = dataset_nm
        if dataset_nm == 'birds':
            self.datasets = Birds(seed, id)
        elif dataset_nm == 'ucsb_breast':
            self.datasets = BreastCancer(seed, id)
        elif dataset_nm == 'messidor':
            self.datasets = Messidor(seed, id)
        else:
            pass

    def get_next_batch(self, step, fold=0, is_train=True, batch_size=1):
        if is_train is True:
            status = 'train'
        else:
            status = 'test'
        step = step % len(self.datasets.data[fold][status])
        if is_train is True and step == 0:
            shuffle(self.datasets.data[fold][status])
        dataset = self.datasets.data[fold][status]

        label = dataset[step]['label']
        fea = np.asarray(dataset[step]['fea'], dtype='float32')
        return fea, label
