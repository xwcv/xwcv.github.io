
function acc = eval_indicators( Z_get, Z_gt )

i = find( Z_get > 0.5 );
acc = length( find(Z_gt(i)>0) ) / length(i);
% fprintf('Accuracy of the predict of indicators is %f.\n', acc);