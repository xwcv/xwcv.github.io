import sys
import cPickle
import numpy as np
from scipy.stats import norm

K = 10
pre = './exp/prostate/res/'
result = []

for round in range(1,11,1):
    result_current = []
    for iter in range(20,1020,20):
        prostate = cPickle.load( open( pre+'round_'+str(round)+'_iter_'+str(iter)+'.dat', 'rb'))

        b_correct, b_total = 0, 0

        for res in prostate:
            bag = res[0]
            probs = res[1]
    
            if bag[2] == 1:
                continue
            gt = bag[1]

            b_total += 1

            prob_vote = probs.mean(0)
            if np.argmax(prob_vote) == gt:
                b_correct += 1
        
        print 'round_'+str(round)+'_iter_'+str(iter)+' accuracy of bag: ' + ('%.3f' % (float(b_correct)/b_total))
        result_current.append(float(b_correct)/b_total)
    result.append(result_current)

with open('./exp/prostate/result_'+str(K)+'_fold.txt', 'w') as f:
    for iline, line in enumerate(result):
        f.write('round_'+str(iline)+' :')
        for isubline, subline in enumerate(line):
            f.write('  '+'%.3f' % subline)
        f.write('\n')
    
    a = np.array(result)
    mean = np.mean(a, axis=0)
    std = np.std(a, axis=0)
    pval = 2*( 1-norm.cdf(mean, 0.5, std) )
    
    f.write('mean: ')
    for isubline, subline in enumerate(mean):
        f.write('  '+'%.4f' % subline)
    f.write('\n')
    
    f.write('std: ')
    for isubline, subline in enumerate(std):
        f.write(' '+'%.4f' % subline)
    f.write('\n')

    f.write('p-value :')
    for isubline, subline in enumerate(pval):
        f.write(' '+'%.4f' % subline)
    f.write('\n')
