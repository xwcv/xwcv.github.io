function d = reconstruct_pca(pcam, y, alpha)

    y2 = y - pcam.MN;
    
    w2 = pcam.PC2'*y;
    e2 = y2 - pcam.PC2*w2;
    d2 = sqrt(sum(e2.^2)/length(e2));
    
    d3 = (w2-pcam.uw)' * pcam.sw * (w2-pcam.uw);
    
    d = alpha(1)*d1 + alpha(2)*d2 + alpha(3)*d3;
    
    

%     dy = y - pcam.PC*pcam.PC'*y;
%     res = sum(dy.^2)/length(y);
    
%     w = w-pcam.U;
%     dis = w'*pcam.SIGMA*w;
%     d = res + alpha*dis;

%     d = res;
